<div>
  Hola
</div>
<?php /**PATH C:\xampp\htdocs\vygdm\resources\views/livewire/back/sidenavbar.blade.php ENDPATH**/ ?>