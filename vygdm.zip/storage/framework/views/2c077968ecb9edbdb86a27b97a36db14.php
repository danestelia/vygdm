<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.cabecera', ['title' => 'Inicio | ']);

$__html = app('livewire')->mount($__name, $__params, '6KUX1nD', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<!--
  Sizes:
  tiny: 1rem
  small: 2rem
  medium: 4rem
  large: 6rem
  -->

<div class="hero">
  <div class="contenedor-menu container">
    <button id="boton-menu" class="boton">Menú</button>
    <nav id="nav-menu" class="">
      <ul class="ul-menu">
        <li><a href="#">
            <i class="large material-icons">home</i>
            <p>Inicio</p>
          </a>
        </li>

        <li><a href="#">
            <i class="large material-icons">sentiment_very_satisfied</i>
            <p>Sobre Nosotros</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">shopping_cart</i>
            <p>Servicios</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">camera</i>
            <p>Galería</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">sms</i>
            <p>Blog</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">phone_in_talk</i>
            <p>Contacto</p>
          </a>
        </li>

      </ul>
    </nav>

  </div>

</div>

<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.piecera', []);

$__html = app('livewire')->mount($__name, $__params, 'UnxxYw1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH C:\xampp\htdocs\vygdm\resources\views/front/index.blade.php ENDPATH**/ ?>