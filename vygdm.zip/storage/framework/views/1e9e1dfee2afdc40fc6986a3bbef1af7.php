<!doctype html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link
    href="https://fonts.googleapis.com/css2?family=Courgette&family=Hanken+Grotesk:wght@400;700;900&family=Merriweather:wght@400;700;900&family=Montserrat:wght@400;500;700&family=Noto+Sans+Thai&family=Roboto+Slab:wght@400;700;900&family=Roboto:wght@400;700;900&family=Ubuntu:wght@400;500;700&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>">
  <!-- UIkit CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/uikit.min.css')); ?>"/>
  <title><?php echo e($title); ?> V & G Diseño Mobiliario s.a.s - Reviviendo tus espacios</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body>
<header>
  <div class="cabecera">
    <a href="<?php echo e(route('inicio')); ?>">
      <div class="logo">
        <img src="<?php echo e(asset('img/logo-redondo.png')); ?>" alt="Logo V y G Diseño Mobiliario S.A.S">
      </div>
    </a>
  </div>
</header>



<?php /**PATH C:\xampp\htdocs\vygdm\resources\views/livewire/front/cabecera.blade.php ENDPATH**/ ?>