<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.cabecera', ['title' => 'Inicio sesión | ']);

$__html = app('livewire')->mount($__name, $__params, 'bWsvznw', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<section class="margen-top container">

  <h1 class="centrar-text">Iniciar sesión</h1>

  <div class="row card">
    <form class="col s12" method="post" action="<?php echo e(route('authenticate')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">email</i>
          <input id="email" type="email" class="validate" name="email" value="<?php echo e(old('email')); ?>" required>
          <label for="email">Correo electrónico</label>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-warning" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">lock</i>
          <input id="password" type="password" class="validate" name="password" value="<?php echo e(old('password')); ?>" required>
          <label for="password">Contraseña</label>
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-warning" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="row centrar-div">
        <button class="btn waves-effect waves-light" type="submit" name="action">Iniciar sesión
          <i class="material-icons right">send</i>
        </button>
      </div>

    </form>
  </div>
</section>

<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.piecera', []);

$__html = app('livewire')->mount($__name, $__params, 'mXoAh6v', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH C:\xampp\htdocs\vygdm\resources\views/front/login.blade.php ENDPATH**/ ?>