<footer>

</footer>
<!-- Compiled and minified JavaScript -->
<script src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
<!-- UIkit JS -->
<script src="<?php echo e(asset('js/uikit.min.js')); ?>"></script>
<script src=""></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\vygdm\resources\views/livewire/front/piecera.blade.php ENDPATH**/ ?>