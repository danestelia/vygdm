<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.cabecera', ['title' => 'Inicio sesión | ']);

$__html = app('livewire')->mount($__name, $__params, 'G6P2O6F', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


<section class="margen-top container">
  <?php if($message = Session::get('success')): ?>
    <div class="uk-alert-success" uk-alert>
      <a href class="uk-alert-close" uk-close></a>
      <p><?php echo e($message); ?></p>
    </div>
  <?php endif; ?>

  <h1 class="centrar-text">Crear usuario nuevo</h1>


  <div class="row card">
    <form class="col s12" method="post" action="<?php echo e(route('store.user')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">account_circle</i>
          <input id="names" type="text" class="validate" name="names" min="3" max="30" required pattern="[a-z A-Z]{3,30}"
                 title="Solo letras" value="<?php echo e(old('names')); ?>">
          <label for="names" class="active">Nombres</label>
          <?php $__errorArgs = ['names'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-danger" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">account_circle</i>
          <input id="apellidos" type="text" class="validate" name="apellidos" pattern="[a-z A-Z]{5-20}" min="5" max="30"
                 required value="<?php echo e(old('apellidos')); ?>">
          <label for="apellidos">Apellidos</label>
          <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-danger" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">phone</i>
          <input id="phone" type="number" class="validate" name="phone" required value="<?php echo e(old('phone')); ?>">
          <label for="phone">Teléfono</label>
          <?php $__errorArgs = ['phones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-danger" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">home</i>
          <input id="adreess" type="text" class="validate" name="adreess" required value="<?php echo e(old('adreess')); ?>">
          <label for="adreess">Dirección</label>
          <?php $__errorArgs = ['adreess'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-danger" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">email</i>
          <input id="email" type="email" class="validate" name="email" required value="<?php echo e(old('email')); ?>">
          <label for="email">Correo electrónico</label>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-danger" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">lock</i>
          <input id="password" type="password" class="validate" name="password" required>
          <label for="password">Contraseña</label>
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="uk-alert-danger" uk-alert>
            <a href class="uk-alert-close" uk-close></a>
            <p><?php echo e($message); ?></p>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="row centrar-div">
        <button class="btn waves-effect waves-light" type="submit">Guardar usuario
          <i class="material-icons right">send</i>
        </button>
      </div>

    </form>
  </div>
</section>

<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('front.piecera', []);

$__html = app('livewire')->mount($__name, $__params, 'gwyjrAn', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH C:\xampp\htdocs\vygdm\resources\views/front/create-user.blade.php ENDPATH**/ ?>