
<button><a href="<?php echo e(route('logout.admin')); ?>">loguot</a></button>

<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('back.sidenavbar', []);

$__html = app('livewire')->mount($__name, $__params, 'l6YLCqi', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH C:\xampp\htdocs\vygdm\resources\views/back/index.blade.php ENDPATH**/ ?>