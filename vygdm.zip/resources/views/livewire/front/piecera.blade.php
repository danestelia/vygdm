<footer>

</footer>
<!-- Compiled and minified JavaScript -->
<script src="{{ asset('js/materialize.min.js') }}"></script>
<!-- UIkit JS -->
<script src="{{ asset('js/uikit.min.js') }}"></script>
<script src=""></script>
</body>
</html>
