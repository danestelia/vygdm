
<button><a href="{{ route('logout.admin') }}">loguot</a></button>

<livewire:back.sidenavbar />
