<livewire:front.cabecera title="Inicio | "/>

<!--
  Sizes:
  tiny: 1rem
  small: 2rem
  medium: 4rem
  large: 6rem
  -->

<div class="hero">
  <div class="contenedor-menu container">
    <button id="boton-menu" class="boton">Menú</button>
    <nav id="nav-menu" class="">
      <ul class="ul-menu">
        <li><a href="#">
            <i class="large material-icons">home</i>
            <p>Inicio</p>
          </a>
        </li>

        <li><a href="#">
            <i class="large material-icons">sentiment_very_satisfied</i>
            <p>Sobre Nosotros</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">shopping_cart</i>
            <p>Servicios</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">camera</i>
            <p>Galería</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">sms</i>
            <p>Blog</p>
          </a>
        </li>

        <li><a href="#">
            <i class="material-icons">phone_in_talk</i>
            <p>Contacto</p>
          </a>
        </li>

      </ul>
    </nav>

  </div>

</div>

<livewire:front.piecera/>
