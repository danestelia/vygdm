<?php

namespace App\Livewire\Back;

use Livewire\Component;

class Sidenavbar extends Component
{
    public function render()
    {
        return view('livewire.back.sidenavbar');
    }
}
