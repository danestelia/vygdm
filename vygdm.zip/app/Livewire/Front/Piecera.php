<?php

namespace App\Livewire\Front;

use Livewire\Component;

class Piecera extends Component
{
    public function render()
    {
        return view('livewire.front.piecera');
    }
}
