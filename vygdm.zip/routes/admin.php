<?php

use Illuminate\Support\Facades\Route;


Route::middleware('auth')->group(function () {

  /* Rutas protegidas para administradores*/

});
