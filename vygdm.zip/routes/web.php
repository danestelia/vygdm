<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\front\PageController;
use App\Http\Controllers\user\UserController;
use App\Http\Controllers\user\LoginController;
use App\Http\Controllers\admin\AdminController;

/* ==== Rutas para páginas del sitio ==== */
Route::controller(PageController::class)->group(function () {
  Route::get('/', 'index')->name('inicio');
});

/* ==== Rutas para adminsitracion del usuario ==== */
Route::controller(UserController::class)->group(function () {
  Route::get('/create-user', 'create')->name('create.user');
  Route::post('/store-user', 'store')->name('store.user');
});

Route::controller(LoginController::class)->group(function () {
  Route::get('/login', 'login')->name('login');
  Route::post('/authenticate', 'authenticate')->name('authenticate');
});

Route::controller(AdminController::class)->middleware('auth')->group(function () {
  Route::get('/admin', 'index')->name('index.admin');
  Route::get('/admin/logout', 'logout')->name('logout.admin');
});
